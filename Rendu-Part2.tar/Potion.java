public class Potion extends CaseBonus {

	public Potion(int val) {
		valeur = val;
	}

	public String getLabel() {
		return "Potion";
	}

}