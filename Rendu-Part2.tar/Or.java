public class Or extends CaseBonus {

	public Or(int val) {
		valeur = val;
	}

	public String getLabel() {
		return "Or";
	}

}